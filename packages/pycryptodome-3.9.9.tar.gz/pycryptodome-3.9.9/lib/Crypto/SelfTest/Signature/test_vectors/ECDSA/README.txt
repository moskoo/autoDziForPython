These files were downloaded from http://csrc.nist.gov/groups/STM/cavp/documents/dss/186-3ecdsatestvectors.zip
on January 9, 2016 and modified to include only test data for P-256 curves (but not in combination with SHA-1
or SHA-224).
